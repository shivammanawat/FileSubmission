CONTENTS 1 Problem Statement 2 2 Proposed Tweet App Wireframe 2 3 Tweet Component Sketch 2 4 Application Architecture 3 5 Tool Chain 4 6 Business-Requirement: 5 7 Rubrics/Expected Deliverables 6 7.1 Rest API (Products & Frameworks -> Compute & Integration): 6 7.2 Database (Products & Frameworks -> Database & Storage): 6 7.3 Messaging (Products & Frameworks -> Compute & Integration): 7 7.4 Log/ Monitoring (Products & Frameworks -> Governance & Tooling): 7 7.5 Debugging & Troubleshooting 7 8 Methodology 8 8.1 Agile 8

  1 PROBLEM STATEMENT Tweet App is SPA (Single Page App) for registered users to post new tweets, reply to tweets, like/unlike tweets. Guest users cannot see any tweets. The core modules of tweet app are:

User registration and login
Post tweet
View users/handles and their respective tweets The scope includes developing the application using toolchain mentioned below. 2 PROPOSED TWEET APP WIREFRAME
UI needs improvisation and modification as per given use case.
3 TWEET COMPONENT SKETCH

4 APPLICATION ARCHITECTURE

  5 TOOL CHAIN Competency Skill Skill Detail Engineering Mindset Networking and Content Delivery Ways of Working Consulting Mindset DevOps Programming Languages Application Language C#.Net Products & Frameworks Presentation Angular Karma & Jasmine Compute & Integration Asp.Net Core Kafka Docker Database & Storage MongoDB Governance & Tooling Git/Azure DevOps Nunit Mockito/Moq Logstash Prometheus & Grafana Engineering Quality Code Quality Sonar Cube

  6 BUSINESS-REQUIREMENT: As an application developer, develop frontend, middleware and deploy the Tweet App (Single Page App) with below guidelines: User Story # User Story Name User Story US_01 Registration and Login As a user I should be able to login/Register in the tweet application Acceptance criteria:

A logged-in user can reset their password so they can login, even if they forget their password.
A logged-in user: a. Cannot change their username. b. Can logout from their account.
As a user I should be able to furnish following details at the time of registration a. First Name b. Last Name c. Email d. Login Id e. Password f. Confirm Password g. Contact Number
All details fields must be mandatory
Login Id and Email must be unique
Password and Confirm Password must be same
If any constraint is not satisfied, validation message must be shown US_02 Post Tweet As a user I should be able to post a tweet Acceptance criteria: a. Tweet should not go beyond 144 characters. b. Tweet can optionally be associated with a tag which should not go beyond 50 characters
US_03 View and Reply Tweet As a user I should be able to view others tweet and reply to it.

Acceptance criteria: a. View others tweet and reply b. Others tweet should display original tweet with all the reply c. Tweet and reply must have user name and time of post displayed along. d. Reply should not go beyond 144 characters e. I should be optionally able to add a tag while replying

7 RUBRICS/EXPECTED DELIVERABLES 7.1 REST API (PRODUCTS & FRAMEWORKS -> COMPUTE & INTEGRATION): a. Use .Net Core API to version and implement the REST endpoints. b. Implement HTTP methods like GET, POST, PUT, DELETE, PATCH to implement RESTful resources: POST /api/v1.0/tweets/register Register as new user GET /api/v1.0/tweets/login Login GET /api/v1.0/tweets//forgot Forgot password GET /api/v1.0/tweets/all Get all tweets GET /api/v1.0/tweets/users/all Get all users GET /api/v/1.0/tweets/user/search/username* Search by username GET /api/v1.0/tweets/username Get all tweets of user POST /api/v1.0/tweets//add Post new tweet PUT /api/v1.0/tweets//update/ Update tweet DELETE /api/v1.0/tweets//delete/ Delete tweet PUT /api/v1.0/tweets//like/ Like tweet POST /api/v1.0/tweets//reply/ Reply to tweet c. username may be partial or complete username d. Use necessary configuration in place for REST API in application.properties or bootstrap. Properties or application.yml; whichever is applicable. e. Package Structure for Asp.net Core Project will be like com.tweetapp. with proper naming conventions for package and beans. f. Use configuration class annotated with @Configuration and @Service for business layer. g. Use constructor-based dependency injection in few classes and setter-based dependency injection in few classes. h. Follow Rest API Naming Conventions i. Document REST endpoints with OpenAPI or Swagger 7.2 DATABASE (PRODUCTS & FRAMEWORKS -> DATABASE & STORAGE):

As an application developer: a. Implement ORM with .Net Core Data MongoRepository and MongoDB. For complex and custom queries, create custom methods and use @Query, Aggregations (AggregationOperation, MatchOperation, AggregationResults), implementation of MongoTemplate etc as necessary. b. Have necessary configuration in place for REST API in application.properties or bootstrap.properties or application.yml OR .Net Core based configuration; whichever is applicable.
7.3 MESSAGING (PRODUCTS & FRAMEWORKS -> COMPUTE & INTEGRATION):

As an application developer: a. Have a centralized logging system b. Be able to communicate using a messaging infrastructure. c. Use KafkaTemplate for communication with .Net Core App and topics in kafka. d. Use kafka for messaging infrastructure and implement producers to write messages/tweets to topic and consumers to read messages/tweets from topic. e. Configure .Net Core app to log all logging messages to kafka. f. Configure all kafka related configuration needed for .Net Core in *.yml file. 7.4 LOG/ MONITORING (PRODUCTS & FRAMEWORKS -> GOVERNANCE & TOOLING):
As an application developer: a. Containerize the complete application, which includes front-end, middleware and kafka (consumers and producers) using docker and Dockerfile. b. Use .dockerignore as necessary to avoid containerizing un-necessary packages. c. Integrate .Net Core Actuator with Prometheus and Grafana to monitor middleware. d. Implement logs with logstash. e. Open the preconfigured Logstash in Kibana and check if it successfully connect to Elasticsearch Server. 7.5 DEBUGGING & TROUBLESHOOTING
Generate bug report & error logs - Report must be linked with final deliverables, which should also suggest the resolution for the encountered bugs and errors.   8 METHODOLOGY 8.1 AGILE
As an application developer, use project management tool along to update progress as you start implementing solution.
Participants should have used estimation techniques, such as Function points, story points, T-Shirt sizing for User Story point estimation
As an application developer, the scope of discussion with mentor is limited to: a. Q/A b. New Ideas, New feature implementations and estimation. c. Any development related challenges d. Skill Gaps e. Any other pointers key to UI/UX and Middleware Development
