import { Component, OnInit } from '@angular/core';
import { FormBuilder,  Validators, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { LoginService } from 'src/app/shared/Services/Login/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  UserLogin: FormGroup;
  submitted = false;
  
  constructor(private fb: FormBuilder, private router: Router, private loginService : LoginService
    , private messageService : MessageService) { }

  ngOnInit(): void {
    this.UserLogin = this.fb.group({
      userName: [ "", [ Validators.required]],
      password: ["", [Validators.required, Validators.minLength(6)]]
    });
  }

  OnSubmit()
  {
      this.submitted = true;
      if (this.UserLogin.invalid) {
        console.log("invalid");
          return;
      }

      this.loginService.login(this.UserLogin.value.userName, this.UserLogin.value.password)
      .subscribe(data =>
      {
          if(data == "User not found")
          {
            this.messageService.add({
              severity: "warn",
              detail: data
            });
          }
          else if( data == "Username or Password is incorrect")
          {
            this.messageService.add({
              severity: "error",
              detail: data
            });
          }
          else if(data == "Enter all the valid required fields")
          {
            this.messageService.add({
              severity: "error",
              detail: data
            });
          }
          else{
            const fullName = data.first_name + " " + data.last_name;
            this.loginService.storeUserData(
              data.userId,
              fullName,
              data.email,
              data.loginId,
              data.token
            );
            this.router.navigate(['/user-dashboard']);
          }
      }, err =>
      {
        this.messageService.add({
          severity: "error",
          detail: "Error"
        });
      });


  }


  
}
