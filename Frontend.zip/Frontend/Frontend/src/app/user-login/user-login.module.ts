import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserLoginRoutingModule } from './user-login-routing.module';
import { LoginComponent } from './login/login.component';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import {ToastModule, Toast} from 'primeng/toast';

@NgModule({
  declarations: [
    LoginComponent
  ],
  imports: [
    CommonModule,
    UserLoginRoutingModule,
    FormsModule,
    ToastModule,
    ReactiveFormsModule
  ]
})
export class UserLoginModule { }
