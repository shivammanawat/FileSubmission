import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddTweetRoutingModule } from './add-tweet-routing.module';
import { TweetComponent } from './tweet/tweet.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastModule } from 'primeng/toast';


@NgModule({
  declarations: [
    TweetComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ToastModule,
    ReactiveFormsModule,
    AddTweetRoutingModule
  ]
})
export class AddTweetModule { }
