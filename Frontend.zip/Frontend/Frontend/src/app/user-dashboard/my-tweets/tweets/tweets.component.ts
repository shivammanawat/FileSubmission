import { Component, OnInit } from '@angular/core';
import { AuthorizedService } from 'src/app/shared/Services/Authorized/authorized.service';
import { FormBuilder,  Validators, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { UserComponent } from '../../user-search/user/user.component';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-tweets',
  templateUrl: './tweets.component.html',
  styleUrls: ['./tweets.component.css']
})
export class TweetsComponent implements OnInit {
  addForm: FormGroup;
  myTweets : any = [];
  userId : number;
  displayNoData : string;
  submitted = false;
  
  user : any;
  first_name : string;
  last_name : string;
  fullName : string;
  constructor(private authorizedService:AuthorizedService, private fb : FormBuilder, private messageService: MessageService) { }

  ngOnInit(): void {
    this.addForm = this.fb.group({
      comments: ['', Validators.required],
    });

    const username = localStorage.getItem("loginId") == null ? "" : localStorage.getItem("loginId");
   
    if(username != null)
    {
      this.getTweetsByUserName(username);
    }

  }

  private getTweetsByUserName(username : string)
  { 
    this.authorizedService.getTweetsByUserName(username).subscribe(data=>
    {
    
      this.myTweets = data;
    
      if( this.myTweets.length  > 0)
      {
        this.displayNoData = "true";
        this.authorizedService.getUserByUserName(username).subscribe(data =>
        {
          this.user = data;
          this.first_name = this.user.first_name;
          this.last_name = this.user.last_name;
        });
      }
      else{
        this.displayNoData = "false";
      }
                                                                                                                                                                                                                                                                  
    });
  }

  deleteTweet(tweetId: any)
  {
    this.authorizedService.deleteTweet(tweetId).subscribe(data =>
    {
        const username = localStorage.getItem("loginId") == null ? "" : localStorage.getItem("loginId");
   
        if(username != null)
        {
          this.getTweetsByUserName(username);
        }
        this.messageService.add({
          severity: "success",
          detail: "Tweet Deleted"
        });
    });

  }

}
