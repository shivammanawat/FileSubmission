import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AuthorizedService } from 'src/app/shared/Services/Authorized/authorized.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  tweetId : string;
  tweet: any = [];

  constructor(private authorizedService: AuthorizedService, private route : ActivatedRoute, private router: Router) { }
 
  ngOnInit(): void {

    this.route.params
      .subscribe(
        (params:  Params) => {
          this.tweetId = params['tweetId'];
          this.getTweetByTweetId(this.tweetId);
        }
      );
  }

  getTweetByTweetId(tweetId : string)
  {
    this.authorizedService.getTweetByTweetId(tweetId).subscribe(data=>
    {
      this.tweet = data;
    })
  }

  editProfile()
  {
    const tweetModel={
      tweetTag: this.tweet.tweetTag,
      tweetDescription: this.tweet.tweetDescription
    }

    this.authorizedService.editProfile(this.tweetId, tweetModel).subscribe(data =>
    {
        if(data  == "Tweet edited successfully")
        {
          this.tweet.tweetTag ="";
          this.tweet.tweetDescription ="";
          this.router.navigate(['user-dashboard/my-tweets']);
        }
    });
  }
  

}
