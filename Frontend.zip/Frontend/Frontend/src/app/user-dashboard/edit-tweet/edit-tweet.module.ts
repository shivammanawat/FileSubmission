import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EditTweetRoutingModule } from './edit-tweet-routing.module';
import { EditComponent } from './edit/edit.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    EditComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    EditTweetRoutingModule
  ]
})
export class EditTweetModule { }
