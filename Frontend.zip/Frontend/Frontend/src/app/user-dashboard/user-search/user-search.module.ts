import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserSearchRoutingModule } from './user-search-routing.module';
import { UserComponent } from './user/user.component';
import { ToastModule } from 'primeng/toast';


@NgModule({
  declarations: [
    UserComponent
  ],
  imports: [
    CommonModule,
    ToastModule,
    UserSearchRoutingModule
  ]
})
export class UserSearchModule { }
