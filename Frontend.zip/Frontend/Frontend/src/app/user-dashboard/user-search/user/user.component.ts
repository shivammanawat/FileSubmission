import { Component, OnInit, Input } from '@angular/core';
import { AuthorizedService } from 'src/app/shared/Services/Authorized/authorized.service';
import { ActivatedRoute, Params } from '@angular/router';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  othersTweets : any = [];
  userId : number;
  userName : string;

  constructor(private authorizedService:AuthorizedService, private route : ActivatedRoute,
    private messageService : MessageService) { }
 
  ngOnInit(): void {

    this.route.params
      .subscribe(
        (params: Params) => {
          this.userName = params['userName'];
          this.getTweetsByUserName(this.userName);
        }
      );
  }
  
  private getUser(username : string)
  {
      this.authorizedService.searchUser(this.userName).subscribe(data=>
      {
          this.othersTweets = data;                                                                                                                                                                                                                                                             
      },
      err =>
      {
        this.messageService.add({
          severity: "error",
          detail: "Error"
        });
      });
  }


  private getTweetsByUserName(username : string)
  {
      this.authorizedService.searchUserTweet(this.userName).subscribe(data=>
      {
          this.othersTweets = data;                                                                                                                                                                                                                                                             
      },
      err =>
      {
        this.messageService.add({
          severity: "error",
          detail: "Error"
        });
      });
  }


}
