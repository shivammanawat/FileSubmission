import { Component, OnInit } from '@angular/core';
import { FormBuilder,  Validators, FormGroup, AbstractControl , ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { RegisterService } from 'src/app/shared/Services/Register/register.service';

import { ConfirmedValidator } from '../../shared/PasswordValidation/confirm-password.validator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  UserRegister : FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder, private router: Router, 
    private registerService : RegisterService, private messageService : MessageService) {
    
  }

  ngOnInit(): void {
    this.UserRegister=this.fb.group({
      firstName: ['',[Validators.required,Validators.pattern('[a-zA-Z ]*')]],
      lastName:['',[Validators.required,Validators.pattern('[a-zA-Z ]*')]],
      loginId:['',Validators.required],
      email:['',[Validators.required,Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      contactNumber:['',[Validators.required,Validators.pattern('^([6-9]{1})([0-9]{9})$')]],
      password:['',[Validators.required,Validators.minLength(6)]],
      confirmPassword:['', [Validators.required, Validators.minLength(6)]]
    },
    {
        validator: ConfirmedValidator("password", "confirmPassword")
    }
  );
}


  onSubmit()
  {

    this.submitted = true;
    if (this.UserRegister.invalid) {
        return;
    }

    var userInfo = 
    {
        first_name:this.UserRegister.value.firstName,
        last_name:this.UserRegister.value.lastName,
        loginId:this.UserRegister.value.loginId,
        email:this.UserRegister.value.email,
        contactNumber:this.UserRegister.value.contactNumber,
        password:this.UserRegister.value.password
    }

    this.registerService.register(userInfo).subscribe(data =>
    {
      if(data == "User registered successfully") {
        this.messageService.add({
          severity: "success",
          detail: data
        });
      }
      else if(data == "User already exists with email or login id") {
        this.messageService.add({
          severity: "error",
          detail: data
        });
      }
      else if(data == "Please enter all the valid inputs") {
        this.messageService.add({
          severity: "error",
          detail: data
        });
      }
      else{
        this.messageService.add({
          severity: "error",
          detail: "Error"
        });
      }
    }, err =>
    {
      this.messageService.add({
        severity: "error",
        detail: "Error"
      });
    });

  }

}
