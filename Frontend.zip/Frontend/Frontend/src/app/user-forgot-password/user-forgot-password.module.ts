import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserForgotPasswordRoutingModule } from './user-forgot-password-routing.module';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastModule } from 'primeng/toast';


@NgModule({
  declarations: [
    ChangePasswordComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ToastModule,
    ReactiveFormsModule,
    UserForgotPasswordRoutingModule
  ]
})
export class UserForgotPasswordModule { }
